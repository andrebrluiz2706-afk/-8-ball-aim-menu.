# 8 BALL AIM MENU — Android

Protótipo Android independente para treino visual de bilhar. Inclui mesa ilustrativa, linhas coloridas, trajetória de referência e controles de ângulo/força.

## Gerar APK automaticamente pelo GitHub
1. Envie **todo o conteúdo desta pasta** para a raiz de um repositório GitHub (incluindo a pasta `.github`).
2. Abra a aba **Actions** do repositório.
3. Se necessário, aceite habilitar GitHub Actions.
4. Abra **Build Android APK** e toque em **Run workflow** (ou aguarde o build automático após enviar arquivos para `main`/`master`).
5. Quando terminar com sucesso, abra a execução concluída, vá até **Artifacts** e baixe `8ball-aim-menu-debug-apk`.
6. Extraia o ZIP do artifact e instale `app-debug.apk` no Android. Talvez seja necessário permitir instalação desse arquivo no navegador/gerenciador de arquivos.

## Gerar pelo Android Studio
Abra esta pasta no Android Studio, aguarde a sincronização e use **Build > Build Bundle(s) / APK(s) > Build APK(s)**. O APK ficará em `app/build/outputs/apk/debug/app-debug.apk`.

Requisitos: Android Studio recente, JDK 17 e Android SDK Platform 35 (ou a versão solicitada pelo Android Studio).

## Limites
Este é um simulador offline independente. Não lê a tela, não injeta código, não automatiza tacadas e não modifica o 8 Ball Pool.
